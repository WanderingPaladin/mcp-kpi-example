"""Investor KPI assistant backend."""
